<?php
require_once "../db.php";

//foreach ($_POST['array'] as $key => $value) {
//    echo $key ." => ". $value . "\n";
//}
//die;

$pos = 1;
foreach ($_POST['array'] as $id) {
    $result = mysqli_query($connect, "UPDATE sortable SET position=$pos WHERE id=$id");
    $pos++;
}