$(document).ready(function () {

    $('#sortme').sortable({
        cursor: 'move',
        axis: 'y', // x
        stop: function (sorted) { // sorted из этого объекта получаем какое именно LI
            // result - все ид у элементов LI
            var result = $('#sortme').sortable('toArray');
            $.ajax({
                url: 'sortable_handler.php',
                type: 'POST',
                data: {array: result},
                success: function(){

                },
                error: function () {
                    alert('error');
                }
            });
        }
    });

    $('li.list-group-item').on('mousedown', function () {
        $(this).css({
            'border': '1px solid #0ebafb',
            'background': '#0ebafb',
            'color': '#fff',
            'opacity': '.6'
        })
    });

    $('li.list-group-item').on('mouseup', function () {
        $(this).css({
            'border': '1px solid #ccc',
            'background': 'transparent',
            'color': '#000',
            'opacity': '1'
        })
    });

});