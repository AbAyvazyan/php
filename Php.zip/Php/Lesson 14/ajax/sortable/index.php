<?php
require_once "../db.php";
$query_str = "SELECT title, id FROM sortable ORDER BY position";
$query_result = mysqli_query($connect, $query_str);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <title>Lesson 2</title>
    <style>
        .list-group li {
            border-radius: 5px;
            margin-bottom: 5px;
        }

        .list-group li:hover {
            cursor: move !important;
        }
    </style>
</head>
<body>
<br><br><br>
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-6 col-sm-offset-3">
            <ul class="list-group" id="sortme">
                <?php while ($row = mysqli_fetch_assoc($query_result)) : ?>
                    <li id="<?= $row['id'] ?>" class="list-group-item">
                        <i class="fa fa-arrows-v" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;
                        <?= $row['title'] ?>
                    </li>
                <?php endwhile; ?>
            </ul>
        </div>
    </div>
</div>

<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/jquery-ui.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="sortable.js"></script>
</body>
</html>