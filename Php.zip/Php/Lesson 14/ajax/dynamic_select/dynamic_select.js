$(document).ready(function () {

    $('#country_dropdown').change(function () {
        var selectedCountryVal = $('#country_dropdown option:selected').val();
        if (selectedCountryVal == 0) {
            clearList();
        }
        getArea();
    });

    $('#area_dropdown').change(function () {
        getCity();
    });
});

function getArea() {
    var selectedCountryVal = $('#country_dropdown option:selected').val();
    var areaSelect = $('#area_dropdown');
    if (selectedCountryVal == 0) {
        areaSelect.attr('disabled', true);
        getCity();
    } else {
        areaSelect.attr('disabled', false);
        areaSelect.load('getarea.php', {selCountryId: selectedCountryVal});
    }
}

function getCity() {
    var selectedCountryValue = $('#country_dropdown option:selected').val();
    var selectedAreaValue = $('#area_dropdown option:selected').val();
    var citySelect = $('#city_dropdown');
    if (selectedCountryValue == 0) {
        citySelect.attr('disabled', true);
    } else {
        citySelect.attr('disabled', false);
        citySelect.load('getcity.php', {selAreaId: selectedAreaValue});
    }
}

function clearList() {
    $('#area_dropdown').empty();
    $('#city_dropdown').empty();
}