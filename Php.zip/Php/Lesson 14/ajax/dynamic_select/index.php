<?php
require_once "../db.php";
$query_str = "SELECT * FROM country";
$query_result = mysqli_query($connect, $query_str);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <title>Lesson 1</title>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-6 col-sm-offset-3">
            <form action="">
                <div class="form-group">
                    <label>Choose Your Country</label>
                    <select class="form-control" id="country_dropdown">
                        <option value="0">Choose Your Country</option>
                        <?php while ($row = mysqli_fetch_array($query_result)): ?>
                        <option value="<?= $row['country_id'] ?>"><?= $row['country'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group" id="area">
                    <label>Choose Your Region</label>
                    <select class="form-control" id="area_dropdown" disabled="disabled">

                    </select>
                </div>
                <div class="form-group">
                    <label>Choose Your City</label>
                    <select class="form-control" id="city_dropdown" disabled="disabled">

                    </select>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="dynamic_select.js"></script>
</body>
</html>