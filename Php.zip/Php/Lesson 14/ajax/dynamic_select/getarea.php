<?php
require_once "../db.php";

$selected_country_id = $_POST['selCountryId'];
$query_str = "SELECT * FROM area WHERE country=" . $selected_country_id;
$query_result = mysqli_query($connect, $query_str);
?>

<option value="0">Choose Your Region</option>
<?php while ($row = mysqli_fetch_assoc($query_result)): ?>
    <option value="<?= $row['area_id'] ?>"><?= $row['area'] ?></option>';
<?php endwhile; ?>

