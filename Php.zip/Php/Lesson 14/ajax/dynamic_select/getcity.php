<?php
require_once "../db.php";

$selected_area_id = $_POST['selAreaId'];
$query_str = "SELECT * FROM city WHERE area=" . $selected_area_id;
$query_result = mysqli_query($connect, $query_str);
?>

<option value="0">Choose City</option>
<?php while ($row = mysqli_fetch_assoc($query_result)): ?>
    <option value="<?= $row['city_id'] ?>"><?= $row['city'] ?></option>
<?php endwhile; ?>