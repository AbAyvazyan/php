$(document).ready(function () {

    $('#search').on('input', function () {
        var searchField = $(this).val();
        // Регистронезависимый поиск
        var myExp = new RegExp(searchField, "i");

        $.getJSON('file.json', function (data) {
            // console.log(data);
            var output = '<ul class="search-result list-group">';
            $.each(data, function (key, value) {
                if ((value.first_name.search(myExp) !== -1) || (value.text.search(myExp) !== -1)) {
                    output += '<li class="list-group-item clearfix">';
                    output += '<h3>' + value.first_name + ' ' + value.last_name + '</h3>';
                    output += '<img src="images/' + value.poster + '.jpg" alt="' + value.first_name + '" >';
                    output += '<p>' + value.text + '</p>';
                    output += '</li>';
                }
            });
            output += '</ul>';

            $('#update').html(output);
        });

    });

});