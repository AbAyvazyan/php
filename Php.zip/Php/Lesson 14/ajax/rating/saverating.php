<?php
require "../db.php";

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $query_str = "SELECT rating FROM rating WHERE id=$id";
    $query_result = mysqli_query($connect, $query_str);
    $row = mysqli_fetch_assoc($query_result);

    $new_rating = $row['rating'] + $_POST['func'];
    mysqli_query($connect, "UPDATE rating SET rating=$new_rating WHERE id=$id");
}