<?php
require "../db.php";
$query_str = "SELECT * FROM rating ORDER BY rating DESC";
$query_result = mysqli_query($connect, $query_str);

?>

<?php while ($row = mysqli_fetch_assoc($query_result)): ?>
    <li class="list-group-item" id="<?= $row['id'] ?>">
        <?= $row['title'] ?>
        <div class="btn-group pull-right">
            <button type="button" id="plus" class="btn btn-success btn-sm">+</button>
            <input type="text" value="<?= $row['rating'] ?>" class="form-control input-sm">
            <button type="button" id="minus" class="btn btn-danger btn-sm">-</button>
        </div>
    </li>
<?php endwhile; ?>
