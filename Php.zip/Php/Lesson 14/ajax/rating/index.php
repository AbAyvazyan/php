<?php
//require "../db.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <style>
        input[type="text"] {
            width: 40px;
            float: left;
            border-radius: 0;
            text-align: center;
            color: #4c5666;
            font-size: 16px;
            padding: 5px 2px;
        }
        li {
            color: #4c5666;
            font-size: 16px;
        }
        .btn-group {
            position: relative;
            top: -5px;
            right: -10px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">

            <h2 class="text-center">Search engine rating</h2>
            <ul class="list-group" id="rating">
                <?php require "rating_content.php" ?>
            </ul>

        </div>
    </div>
</div>
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="rating.js"></script>
</body>
</html>