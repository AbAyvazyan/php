$(document).ready(function () {
    $('button').on('click', function () {
        var currentId = $(this).attr('id');
        var parentId = $(this).parent().parent().attr('id');
        editRating(currentId, parentId);

        function editRating(sign, element) {
            switch (sign) {
                case 'plus':
                    $.ajax({
                        url: "saverating.php",
                        type: "POST",
                        data: {id: element, func: 1},
                        success: function () {
                            reload();
                        },
                        error: function () {
                            alert("Error")
                        }
                    });
                    break;
                case 'minus':
                    $.ajax({
                        url: "saverating.php",
                        type: "POST",
                        data: {id: element, func: -1},
                        success: function () {
                            reload();
                        },
                        error: function () {
                            alert("Error")
                        }
                    });
                    break;
            }
        }
        function reload() {
            $.ajax({
                url: "rating_content.php",
                cache: false,
                success: function (html) {
                    $('#rating').html(html);
                    $('button').on('click', function () {
                        var currentId = $(this).attr('id');
                        var parentId = $(this).parent().parent().attr('id');
                        editRating(currentId, parentId);
                    });
                    // location.reload(); // Перезагружает страницу
                }
            });
        }
    });
});