-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Июн 15 2018 г., 15:37
-- Версия сервера: 10.1.32-MariaDB
-- Версия PHP: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ajax`
--

-- --------------------------------------------------------

--
-- Структура таблицы `area`
--

CREATE TABLE `area` (
  `area_id` int(11) NOT NULL,
  `country` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `area`
--

INSERT INTO `area` (`area_id`, `country`, `area`) VALUES
(1, '5', 'Київська'),
(2, '1', 'Вінницька'),
(3, '2', 'Московская'),
(4, '5', 'Волинська'),
(5, '1', 'Дніпропетровська'),
(6, '1', 'Донецька'),
(7, '2', 'Ставрапольский край'),
(8, '8', 'Закарпатська'),
(9, '4', 'Запорізька'),
(10, '2', 'Тюменьская область'),
(11, '1', 'Кіровоградська'),
(12, '6', 'Луганська'),
(13, '1', 'Львівська'),
(14, '3', 'Миколаївська'),
(15, '7', 'Одеська'),
(16, '2', 'Полтавська'),
(17, '8', 'Рівненська'),
(18, '4', 'Сумська'),
(19, '3', 'Тернопільська'),
(20, '2', 'Липецк область'),
(21, '3', 'Херсонська'),
(22, '6', 'Хмельницька'),
(23, '7', 'Черкаська'),
(24, '2', 'Ростовская область'),
(25, '3', 'Чернігівська'),
(26, '1', 'АР Крим'),
(27, '3', 'Брестская'),
(28, '3', 'Гомельская'),
(29, '3', 'Гродненская'),
(30, '3', 'Могилёвская'),
(31, '3', 'Минская'),
(32, '3', 'Витебская');

-- --------------------------------------------------------

--
-- Структура таблицы `city`
--

CREATE TABLE `city` (
  `city_id` int(11) NOT NULL,
  `city` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `city`
--

INSERT INTO `city` (`city_id`, `city`, `area`, `country`) VALUES
(1, 'Київ', '1', '1'),
(2, 'Москва', '3', '2'),
(3, 'Минск', '31', '3'),
(4, 'Донецьк', '6', '1');

-- --------------------------------------------------------

--
-- Структура таблицы `country`
--

CREATE TABLE `country` (
  `country_id` int(11) NOT NULL,
  `country` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `country`
--

INSERT INTO `country` (`country_id`, `country`) VALUES
(1, 'Україна'),
(2, 'Россия'),
(3, 'Беларусь'),
(4, 'Австралия'),
(5, 'Австрия'),
(6, 'Азербайджан'),
(7, 'Албания'),
(8, 'Алжир'),
(9, 'Американское Самоа');

-- --------------------------------------------------------

--
-- Структура таблицы `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `message`
--

INSERT INTO `message` (`id`, `user_name`, `text`) VALUES
(1, 'Jon', 'First message'),
(2, 'Jek', 'Secon message'),
(3, 'Alex', 'New message'),
(4, 'Bruno', 'Hello AJAX'),
(5, 'Ketrin', 'Hello JavaScript'),
(6, 'Snowden', 'JS AJAX'),
(7, 'Miki', 'Hello World !!!'),
(8, 'Vadim', 'Novoe soobshenie...'),
(9, 'Armen', 'Armen message text'),
(31, 'JavaScript', 'Jquery React JS Angular'),
(32, 'Vardan', '784561230'),
(33, 'Lilit', 'Hello PHP 7'),
(34, 'Vardan', 'Hello JavaScript and PHP and JQuery AJAX'),
(35, 'tyjrtyj', 'urtyurtyurty');

-- --------------------------------------------------------

--
-- Структура таблицы `rating`
--

CREATE TABLE `rating` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rating`
--

INSERT INTO `rating` (`id`, `title`, `rating`) VALUES
(1, 'google.com', 36),
(2, 'yahoo.com', 25),
(3, 'yandex.ru', 19),
(4, 'bing.com', 8),
(5, 'duckduckgo.com', 3),
(6, 'dogpile.com', 5),
(7, 'yippy.com', 20),
(8, 'ask.fm', 11);

-- --------------------------------------------------------

--
-- Структура таблицы `sortable`
--

CREATE TABLE `sortable` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sortable`
--

INSERT INTO `sortable` (`id`, `title`, `position`) VALUES
(1, '3.Google', 6),
(2, '1.Yandex', 1),
(3, '2.Bing', 4),
(4, '4.Gmail', 3),
(5, '6.Facebooc', 7),
(6, '5.Bootstrap', 2),
(7, '7.Material DL', 5);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`area_id`);

--
-- Индексы таблицы `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`city_id`);

--
-- Индексы таблицы `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Индексы таблицы `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sortable`
--
ALTER TABLE `sortable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `area`
--
ALTER TABLE `area`
  MODIFY `area_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `city`
--
ALTER TABLE `city`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `country`
--
ALTER TABLE `country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT для таблицы `rating`
--
ALTER TABLE `rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `sortable`
--
ALTER TABLE `sortable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
