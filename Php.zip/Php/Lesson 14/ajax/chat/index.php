<?php
require_once "../db.php";
$query_string = "SELECT * FROM message ORDER BY id DESC";
$query_result = mysqli_query($connect, $query_string);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chat</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <style>
        .message-block {
            width: 100%;
            height: 208px;
            overflow-x: hidden;
            overflow-y: scroll;
        }
        .message-block li:nth-child(odd) {
            background-color: #eee;
        }
        a.pull-right {
            color: red;
        }
    </style>
</head>
<body>
<br>
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-sm-offset-2">
            <div class="message-block">
                <ul class="list-group" id="message">
                    <?php while ($message = mysqli_fetch_assoc($query_result)): ?>
                        <li class="list-group-item" id="<?= $message['id'] ?>">
                            <b><?= $message['user_name'] ?>: </b>
                            <?= $message['text'] ?>
                            <a href="#" class="pull-right del_link" id="del_link">
                                <span class="glyphicon glyphicon-remove-circle"></span>
                            </a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            </div>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-sm-offset-2">
            <form id="chat-form">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name">
                </div>
                <div class="form-group">
                    <label for="name">Message:</label>
                    <textarea name="text" id="text" class="form-control" rows="6"></textarea>
                </div>
                <div class="form-group">
                    <button type="button" class="btn btn-success" id="sendBtn">
                        Send
                        <span class="glyphicon glyphicon-send"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="script.js"></script>
</body>
</html>