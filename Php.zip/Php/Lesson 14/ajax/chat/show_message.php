<?php
require_once "../db.php";

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $query_string = "SELECT * FROM message WHERE id > " . $id;
    $query_result = mysqli_query($connect, $query_string);
    if ($query_result) {
        while ($message = mysqli_fetch_assoc($query_result)) {
            echo '<li class="list-group-item" id="' . $message['id']
                .'"><b>' . $message['user_name'] . ': </b>' . $message['text']
                . '<a href="#" class="pull-right" id="del_link"><span class="glyphicon glyphicon-remove-circle"></span></a></li>';
        }
    }
}

