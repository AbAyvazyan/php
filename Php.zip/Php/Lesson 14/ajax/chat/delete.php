<?php
require '../db.php';

$id = $_POST['id'];

$sql = "DELETE FROM message WHERE id=$id";
if(mysqli_query($connect,$sql)){
    echo  'success';
}