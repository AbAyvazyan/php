<?php
require_once "../db.php";

if (isset($_POST['name']) && isset($_POST['text'])) {
    $name = $_POST['name'];
    $text = $_POST['text'];

    $query_string = "INSERT INTO message (user_name, text) VALUES ('$name', '$text')";
    $query_result = mysqli_query($connect, $query_string);
}
