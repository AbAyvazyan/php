<?php

require_once "./db.php";


if (isset($_POST['id'])){

$id = $_POST['id'];

$query_string = "DELETE  FROM message WHERE id=".$id;

$query_result = mysqli_query($connect,$query_string);

}


