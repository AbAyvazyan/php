 <?php 

 require_once "./db.php";

if (isset($_POST['id'])){

$Id = $_POST['id'];

$query_string = "SELECT * FROM message WHERE id >".$Id;
$query_result = mysqli_query($connect,$query_string);

if($query_result){
    while($message = mysqli_fetch_assoc($query_result)) {
        echo '<li class="list-group-item" id = "'.$message['id']
        .'"><b>' . $message["user_name"] . ':</b>' . $message['text']
        . '<a href="#" class="pull-right del_link" id="del_link"><span >&#10060;</span></a></li>';
       ?> 

<script>
$(".del_link").on('click',function () {
        var data = {
            id:$(this).parent().attr('id')
        };
        var a = $(this);
        $.ajax({
            url: "delete.php",
            type: "POST",
            data: data,
            success: function () {
                a.parent().remove();
            }
        });
    })
</script>

    <?php
    }
}
}








