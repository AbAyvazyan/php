$(document).ready(function () {

    window.setInterval(function () {
        var lastId = $("#message li:first-child").attr("id");
        $.ajax({
            url: "show_message.php",
            type: "POST",
            data: {id: lastId},
            success: function (data) {
                if (data) {
                    $('#message').prepend(data);
                }
            }
        });
    }, 500);

    $('#sendBtn').on('click', function () {
        var data = {
            name: $('#name').val(),
            text: $('#text').val()
        };
        $.ajax({
            url: "new_message.php",
            type: "POST",
            data: data,
            success: function () {
                $('#chat-form')[0].reset();
            }
        });
    });







    $(".del_link").on('click',function () {
        var data = {
            id:$(this).parent().attr('id')
        };
        var a = $(this);
        $.ajax({
            url: "delete.php",
            type: "POST",
            data: data,
            success: function () {
                a.parent().remove();
            }
        });
    })
});