<?php
// Interface-@ abstract class e, vori bolor method-ner@ abstract en
// dra hamar abstract bar@ chi grvum, ev classi anunic araj el grvuma interface
interface Hand{
    function useKeys();
    function touchNose();
}
interface Foot{
    function run();
    function play();
}
class Human extends A implements Hand, Foot{
    function useKeys(){
        echo 'sad';
    }
    function touchNose(){
        echo"asdsad";
    }
    function run(){

    }
    function play(){

    }
}

// final method
// chen karox kanchvel extend exac-um
// chi uzum hexinak@ kam avartvac chi der
//class Math{
//    final function countSum($a, $b){
//        echo "Summ: " . ($a + $b);
//    }
//}
//class Algebra extends Math{
//
//    function countSum($a, $b){
//        $c = $a + $b;
//        echo "Summ: $a and $b = $c";
//    }
//}
//$b = new Algebra();
//$b->countSum(5,6);

/// inchpes method@, aynpes el class-@ karox e linel final, nranic hnaravor CHE jarangel

 /**
* 
*/
//final class ClassName
//{
//    function doSomething(){
//        //
//    }
//}
//echo '<pre>';
//print_r(get_declared_classes());


?>