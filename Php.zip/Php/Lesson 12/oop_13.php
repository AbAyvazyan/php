<?php

//abstract class Db{ //abstract class-ic miayn jarangum en
//// partadir che vor unena abstract method-ner
//// bayc ete class-um ka abstract method, apa ayd class-@ partadir petqa lini abstract class
//    public $conn;
//    function connect(){
//        ////////
//    }
//    abstract function open();
//    abstract function query();
//    abstract function close();
//}
//$myDb = new Db; //error kstananq, chi kareli Abstract classic object stexcel

////////////////////////////////////////////////////////
//abstract class AbstractClass
//{
////   /* tvyal methodner@ petqa bnutagrven jarangox class-um */
//    abstract function getValue();
////    abstract function prefixValue($prefix);
////
////   /* sovorakan @ndhanur method */
//    public function printOut() {
//        print $this->getValue();
//    }
//}

//
//
//
//class Class1 extends AbstractClass{
//    public function getValue() {
//        return "Class1";
//    }
////
//    public function prefixValue($prefix) {
//        return "{$prefix}Class1";
//    }
//
//}
//
////
//class Class2 extends AbstractClass
//{
//    public function getValue() {
//        return "Class2";
//    }
//
//    public function prefixValue($prefix) {
//        return "{$prefix}Class2";
//    }
//}

//$class1 = new Class1;
//$class1->printOut();
//echo $class1->prefixValue('FOO_') ."\n";
////
//$class2 = new Class2;
//$class2->printOut();
//echo $class2->prefixValue('FOO_') ."\n";




//
//class A{
//    public $a;
//    protected $b;
//    private $c;
//
//    function __construct()
//    {
//        echo 'hi';
//    }
//
//    function __destruct()
//    {
//       echo 'bye';
//    }
//
//    function ok($h){
//        $this->b = $h;
//    }
//}
//
//$a = new A();
//$b = new A();
//$a->ok('hello');
//
//
//
//
//final class B{
//
//}


// class  A {
//   final  function yes(){
//        echo 'hello';
//    }
//}
//
//class B extends A{
//
//}




?>