<?php

//class Car{
//    public $color = 'Black';
//    public $brand;
//
//    function go(){
//        echo 'go';
//    }
//}
//
//$bmw = new Car;
//$benz = new Car;
//$bmw->brand = 'BMW';
//echo $bmw->brand;
//$bmw->go();
//echo $benz->color;

//
//
//class Animal{ //sa class-n e
//	public $name; //svoystva // property
//	public $age = 0;
//	function sayHello($word){
//		echo $this->name.' says '.$word;
//		$this->drawBr();
//	}
//	//metod-i nersum ayl metodin dimum enq $this-ov
//	function drawBr(){
//		echo '<br>';
//	}
//   function __construct($num){
//       echo 'Object '.$num.' created<br>';
//   }
//   function __destruct(){
//       echo 'Object deleted<br>';
//   }
//   function __clone(){
//       echo 'Object Cloned<br>';
//   }
//}

//$cat = new Animal(1);
//$dog = new Animal(2);
//$dog->name = 'Rex';
//$cat->name = 'Bob';
//$cat->sayHello('myau');
//$dog->sayHello('Hach');
//$bigCat = clone $cat;




//
//$cat = new Animal('gjhgfjkg'); //sa object e// class-i exemplyar
//$dog = new Animal(2); //sa object e
//$bird = new Animal(200);
////
//$cat->name = 'Tom'; //objectin arjeq enq talis
////$cat->name = 'BoB'; //objectin arjeq enq talis
////$bigCat = clone $cat;
////$bigCat->name='Tom';
////$dog->name = 'Rex';
////$bird->name = 'Citik';
////echo $cat->name; //$cat-@ popoxakann e, isk name-@ svoystvan
////echo '<br>';
////echo $dog->name;
////objectn uni povedeniya, povedenian nkaragrvum e metod-nerov
////metod-@ php-um da sovorakan funkcia e, uxaki class-i nersum
//$cat->sayHello('Myau'); //sa aranc echo-i enq grum
////
////$dog->sayHello('Hach'); //echo-n funkciayi mej enq grel
//
//
//////metodic svoystva-nerin dimum enq miayn this - mijocov (nshanakuma-sra)
////$bird->sayHello('Civ-Civ');
//
//
////CONSTRUCTOR-@ oop-um METOD e vorn avtomat kanchvum e OBJECT-i stexcvelu jamanak
////DESTRUCTOR
////CLONE
//
////Metodi mej svoystvayin dimelu hamar ogtagorcvum e $this -@
//
//
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///*
//class-@ parz xosqerov asac, da object-i naxagicn e, esqiz@, vori himan vra el stexcvum e irakan object-@.
//orinak. ka meqenayi class-@, ev dra himan vra stexcvum e irakan meqenan- object-@.
//
//
//
//*/
//
//
//

?>




