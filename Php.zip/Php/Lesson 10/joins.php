<?php
/* JOIN TYPES 
 * 
 * 1) INNER JOIN
 * 2) 

*/

//-------INNER JOIN -------// 
//Miacnuma erku table-ner@ mer nshac paymani depqum 
//ev mer nshac tvyalnerna vercnum
SELECT user.name, phone.brand, phone.model
FROM users INNER JOIN phones
ON user.phone_id=phone.id
////////////////////////////////////////////////////



?>