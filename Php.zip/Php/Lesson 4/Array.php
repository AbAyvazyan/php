

<html>
<head>
	<title>Arrays</title>
</head>

<body>
<h1>Array</h1>
<?php

//$arr = ["It's a", " wonderful", "world"];
//$arr[] = 'bye';
//$arr[] = 'bye';
//$arr[10] = 'hi';
//$arr[] = 'bye';
//unset($arr[10]);
//echo '<pre>';
//print_r($arr);


//
//$a[]="hello";
//////
//$a[]="dsad";
//$a[4]='asdasd';
//$a[] ='sdf';
////echo '<pre>';
//print_r($a);
///*-------------Basic/Indexed Arrays--------------*/
$rainbow = array();
//
////
//$rainbow = array("red", "orange", "yellow", "green", "blue", "indigo", "violet");
//$num=count($rainbow);
////echo $num;
//for($i=0;$i<$num;$i++){
//    echo $rainbow[$i]."<br>";
//}
//echo $rainbow[1]; //index = 1, the value is "orange"
//
//
///*--------------------------------------*/
//// ete uzum enq sksel index-i urish arjeqic, apa grum enq ayspes
//$arr = array(2=>"red", 3=>"orange", 4=>"yellow");
//////kam, vor nuynn e, ayspes
//$arr[2] = "red";
//$arr[3] = "orange";
//$arr[4] = "yellow";
////
//echo "$arr[2] $arr[3], $arr[4]";
/*--------------------------------------*/



//$arr=[];
//$arr = array("mek",18, "erku", array("x", 5, array(1,2)),5);
//if(is_array($arr)){
//    echo "asdasd";
//}
//$arr = [[1,2],[5,[7,8]],[7]];
//echo $arr[1][1][1];

//echo $arr[3][2][1];
//echo $arr[3][0];
//echo $arr[3];
//echo $arr[0].'<br>';
//echo $arr[3];
//echo $arr[3][1];
////
// echo "<pre>";
//print_r($arr);
// echo "</pre>";
//
//echo $arr[3][1]; // will show the number 5
//
//$arr[1] = 55; //18-will change with 55
//print_r($arr);
//echo $arr[1];
//$arr[4] = "new element"; //adding a new element
////
// echo "<pre>";
//print_r($arr);
// echo "</pre>";

//$arr[] = "also new element"; // if you dont know the length of array
//print_r($arr);
//$arr[]=1;
//echo "<pre>";
//print_r($arr);
//$b[]="hello";
//print_r($b);
//
//$arr = ["one"=>'mek', "two"=>"erku", "three"=>"ereq"]; //short array syntax (started with PHP-5.4)
//foreach ($arr as $f => $k){
//    echo $f.':'.$k.'<br>';
//}

?>