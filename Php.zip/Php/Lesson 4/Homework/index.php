<?php

//-------------------------------------------------------1-----------------------------------------

// $languages = ["HTML","CSS","PHP","JavaScript","JQuery","MySql","OOP"];

// foreach($languages as $k){
//     echo $k."<br>";
// }

//----------------------------------------------------------2-----------------------------------------

// $sum = [5, 6, 9, 3, 16, 21];

// echo array_sum($sum);

// $b = 0;

// foreach ($sum as $value) {
//     $b+=$value;
// }
// echo $b;

//-------------------------------------------------------------------3-----------------------------

// $name = ['Armen'=>'Petrosyan',
//         'David'=>'Sargsyan',
//         'Garik'=>'Hovhannisyan'];

//         foreach ($name as $key => $value) {
//             echo $key." : ".$value."<br>";
//         }


//--------------------------------------------------------------------4---------------------------

// $arr = ['http://google.com', 'https://youtube.com', 'https://vk.com',"http://asbckabcbashc"];

// foreach ($arr as $value) {

//     if(!substr_compare($value ,"http:",0,5)) 
// {
//      echo $value."<br>";
// }
// }



?>