<?php
//$colors = array("red", "green", "blue", "yellow"); // arrayi veragrum
//////
//foreach ($colors as $abg => $cde ) {
//   echo "$abg $cde<br>";
//}
//Indexed array
//$ages = array(10,15,20,25,30,35);
////////
//foreach($ages as $age=>$a){
//	echo "AGE: $age<br>";
//}
//
////Associative array
//
//foreach($array as $key => $value){
////	//statement;
//}
//
//$jobs = array(
//		"first_name" => "Steve",
//		"last_name" => "Jobs",
//		"brand" => "Apple",
//		"status" => "Genius",
//	);
////
//foreach($jobs as $key => $value){
//	echo $key.'----'.$value ."<br>";
//}

?>