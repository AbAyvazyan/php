<?php

return [
    'host' => 'localhost',
    'dbname' => 'mvc',
    'user' => 'root',
    'password' => '',
    'charset' => 'utf8'
];