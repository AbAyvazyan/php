<?php

include ("connection.php");

$sql = "DELETE FROM brands WHERE id  IN (3,4) ";
mysqli_query($conn, $sql);