<?php
include("connection.php");

/*  UPDATE syntax

UPDATE table_name
SET column1=value, column2=value2,...
WHERE some_column=some_value
*/

$sql = "UPDATE brands SET name='Adidas' WHERE country='Japan'";
if (mysqli_query($conn, $sql)) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . mysqli_error($conn);
}

mysqli_close($conn);

?>