<?php


/*         If , else , elseif           */


$a = 9;
$b = 8;
////
//if ($a < $b) {
//    echo "OKey";
//    echo "asd";
//    echo "Asdasd";
//}

//
//if ($a > $b) {
//    echo "a-n mec e b-ic";
//} elseif ($a == $b) {
//    echo "a-n havasar e b-in";
//} else {
//    echo "a-n poqr e  b-ic";
//}


//if ($a < $b):
//    echo "$a is greater than $b";
//     echo 'asd';
//elseif ($a == $b): // Will not compile.
//    echo "barev";
//else:
//    echo 'asdas';
//endif;

//if ($a > $b):
//    echo $a." is greater than ".$b;
//elseif ($a == $b): // Note the combination of the words.
//    echo $a." equals ".$b;
//else:
//    echo $a." poqr e ".$b;
//endif;

//
//if($a>$b):
//    echo $a;
//
//    echo $b;
//endif;
//    echo 5;
//   sxal e

//
if ($a > $b) {
    echo "a is bigger than b";
} elseif ($a == $b) {
    echo "a is equal to b";
} elseif ($a>5) {
    echo "...";
} else {
    echo "a is smaller than b";
}

?>