<?php
//
//$num = 5;
//$a = print null;
//echo $a;
//PHP TAGS
/*
 *  1.    <?php  ?>
 *  2.    <?     ?>
 *  3.    <%     %>
 *  4.    <script language="php">
 *  5.    <?=    ?>
 *  6.    <%=    %>
 */
        // Mi toxi hamar naxatesvac (c++ style)
        #  Mi toxi hamar naxatesvac
        /*  Mi qani tox hamar naxatesvac comment
        dsfkjdfkljsdf ds fsjkdh
        sdjfhsdfklsdj
        sdjfhksdf  */
//$a = 5;
//////echo "hello ".$a."  ".$a;
//$b = 1 + $a;
//echo $b;
//Echo Print
//echo $a    .   'asdasd' ;
//
//echo 5;
//echo 'hello',' ',"world",5;
//print 'hello';
//print "Hello";
//$a = print "hello";
//echo $a;
//$__a=5;
//echo $__a;
//     echo "Artacvox arjeq"," 2rd arjeq";
//     print "Artacvox arjeq";
//Variable in PHP
//$a = 4;
//echo $a;
//echo $a;
//$a =5;
//echo $a;
//$num = '5';
//var_dump($num);
//$num = 6;
//    $num = 5;
//    echo $num;
//    var_dump($num);
//    unset($num);
//    echo $num;
////var_dump($num);
////    echo $num;
//    $num2 = &$num;
//    echo $num2;
//    $num2 = 7;
//    $num = 10;
//    echo $num2.' '.$num;
//Types in PHP
//     boolean
//     booleany yndunum e 2 arjeq TRUE kam FALSE
//     $world = 1==1;
//     var_dump($world);
    // null
    // null tipi popoxakannery karox en unen miayn NULL arjeqy
//     $a = null;
//     var_dump($a);
    // string
//     stringy grvuma ' ' kam " " mej;
//     $num =5;
//     $text = "some text $num";
//     var_dump($text);
    // integer
//     -2,147,483,648 ic minchev 2,147,483,647
//     $num = 5;
//     var_dump($num);
    // float
    // amboxjakan tvery
//     $num = 5.0;
//     var_dump($num);
     // array
//      $fruits = [[5,6],5,"banan"];
//      echo $fruits;
//      var_dump($fruits);
//    echo '<pre>';
//    print_r($fruits);
//    echo $fruits[0];
//     object
//    class Book {
//        public $author = "Isahakyan";
//        public function good(){
//            echo "Lav girq e";
//        }
//    }
//////
//    $hexinak = new Book();
//
//    echo $hexinak->author;
//    $hexinak->good();
//
//
//
//$var = 0;
//$var2 = 0.0;
//$var3 = "";
//$var4 = "0";
//$var5 = [];
//$var6 = null;
//settype($var, "boolean");
//settype($var2, "boolean");
//settype($var3, "boolean");
//settype($var4, "boolean");
//settype($var5, "boolean");
//settype($var6, "boolean");
//var_dump($var);
//var_dump($var2);
//var_dump($var3);
//var_dump($var4);
//var_dump($var5);
//var_dump($var6);
//$var = 12;
//echo gettype($var);
//echo 'hello'.' '.'world';
//$num = "hel555lo";
//$new_var = (float) $num;
//var_dump($num);
////echo gettype($num);
//echo gettype($new_var);
//echo  $new_var;
//echo intval(42);
//echo intval(4.2);
//echo '<br>';
//echo intval('55aaa42aaa');
?>