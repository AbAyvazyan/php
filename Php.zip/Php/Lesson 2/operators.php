<?php



/*          Arithmetic Operators           */

//          +$a
//          -$a	        	$a-i hakadir arjeq
//          $a + $b	    	$a ev $b gumar
//          $a - $b	        $a ev $b tarberutyun
//          $a * $b	        $a ev $b artadryal
//          $a / $b	        $a bajanac $b-i vra
//          $a % $b	        $a-n $b-i vra bajaneluc stacvac mnacord
//          $a ** $b	    $a barcracrac $b astijanov Introduced in PHP 5.6.



//$a = 5;
//$b = -5;
//var_dump(+$a,+$b);

//$c = '10';
//var_dump(+$c);

//$a = 5;
//$b = -6;
//var_dump(-$a,-$b);

//$a = '5';
//$b = '6';
//var_dump(-$a,-$b);

//$a = 2;
//$b = 3;
//$c = $a/$b;
//echo $c."<br>";
//echo $a/$b;

//$a = '10';
//$b = 5;
//echo $a + $b . '<br>';
//echo $a * $b . '<br>';
//echo $a / $b . '<br>';
//echo $a - $b . '<br>';

//$a = 5;
////$a = $a *5;
//$a *=5;
//echo $a;
//$a = 1;
//$b = 2;
//$a = $b += 3;
//echo $a . '<br>';
//echo $b . '<br>';
//
//$a = 3;
//$a += 5;
//echo $a;
//$b = 'dsfsd';
//$b .= "Hello ";
//$b .= "There!";
//echo $b;

//echo (5 % 3)."<br>";
//echo (5 % -3)."<br>";
//echo (-5 % 3)."<br>";
//echo (-5 % -3)."<br>";

//$a = 10;
//if (($a % 2) == 1)
//{ echo "$a is odd." ;}
//if (($a % 2) == 0)
//{ echo "$a is even." ;}

//$a = 25;
//echo $a % 5;

//$a = 4;
//$b = 2;
//echo $a ** $b;

//PHP 7
//echo 1 <=> 1; // 0
//echo -1 <=> 2; // -1
//echo 4 <=> 1; // 1

//echo null??'aa';


/*         Logical Operators            */

//$a and $b         True e ete erkusn el true en
//$a or $b	        True e ete $a ev $b ic gone meky true e
//$a xor $b	        True e ete $a ev $b ic meky true e, bayc voch erkusy miajamanak
//! $a	            True ete $a -n false e
//$a && $b      	True e ete erkusn el true en
//$a || $b	        True e ete $a ev $b ic gone meky true e


//$a = false || true;
//$b = false or true;
//var_dump($a,$b);

//$a = false && true;
//$b = true and false;
//var_dump($a, $b);


//function a($x) { echo 'Expression '; return $x; }
//function b($x) { echo 'is '; return $x; }
//function c($x) { echo $x ? 'true.' : 'false.' ;}

//c( a( false ) and b( true ) );
//c( min( a( false ), b( true ) ) );
//
//c( a( false ) or b( true ) );
//c( max( a( true ), b( true ) ) );



//

//$tom = false or 'Tom';
//
//$tom = false or $tom = 'Tom';

//$tom = true ? false : 'Tom';

//
//var_dump($tom);


//$x = 54;
//
//$x = 17 && isset($x) ;
//////
//var_dump($x); // 17

?>

