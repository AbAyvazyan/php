<?php


/*  Switch  */
//$a = 2;
//switch ($a) {
//    case 0:
//        echo "a equals 0";
//        break;
//    case 1:
//        echo "a equals 1";
//        break;
//    case 2:
//        echo "a equals 2";
//        break;
//    case 3:
//        echo 'bye bye';
//        break;
//
//}
//echo "default";
        /*  Switch  */

//$a = 1;
////
//switch ($a) {
//    case 0: break;
//    case 1:
//    case 2:
//        echo $a;
//    case 3:
//        echo " a is 3";
//        break;
//    case 4:
//        echo " a is 4";
//}
////
//$a = 1;
////
//switch ($a) {
//    case 0:
//        echo "a equals 0";
//        break;
//    case 1:
//        echo "a equals 1";
//        break;
//    case 2:
//        echo "a equals 2";
//        break;
//    default:
//        echo "a is not equal to 0, 1 or 2";
//}

//$car = 'BMW';
////
//switch($car)
//{
//    case 'BMW':
//        echo 'This is BMW';
//    case 'Mercedes Benz':
//        echo 'This is Benz';
//    case 'Audi':
//        echo 'Good choice';
//        break;
//    default;
//        echo 'Please make a new selection...';
//        break;
//}

//
//$a=5;
//$a++;
//echo ++$a;
////echo $a++;
//echo $a;




//        $a = 0;
////////
//if(++$a == 3) echo 3;
//elseif(++$a == 2) echo 2;
//elseif(++$a == 1) echo 1;
//else echo "No match!";


//switch(++$a) {
//    case 3: echo 3; break;
//    case 2: echo 2; break;
//    case 1: echo 1; break;
//    default: echo "No result!"; break;
//}

//$string = 'PHP';
////
//switch($string)
//{
//    case  "PHP":
//        echo "this is PHP";
//        break;
//    case "JS":
//        echo "this is JS";
//        break;
//    case 'CSS':
//        echo "this is CSS";
//        break;
//}


//$string="2string";
//
//switch($string)
//{
//    case 1:
//        echo "this is 1";
//        break;
//    case '2string':
//        echo "this is a string";
//        break;
//    case 2:
//        echo "this is 2";
//        break;
//    case 21:
//        echo "this is 21";
//        break;
//
//}


//$zero = '21sdf';
//switch($zero){
//    case NULL: echo "NULL";  break;
//    case 0: echo "zero";  break;
//
//    default: echo "other"; break;
//}



//$zero = 0;
//switch(TRUE){
//    case (NULL === $zero): echo "NULL" ;break;//blah break;
//    case (0   === $zero): echo "0";//etc. break;
//}

//for($i=0; $i<8; ++$i)
//{
//    echo $i,"\t";
//    switch($i)
//    {
//        case 1: echo "One<br>"; break;
//        case 2: echo "\t";
//        case 3: echo "\t";
//        case 4: echo "Three or Four<br>"; break;
//        case 5: echo "Five<br>"; break;
//        default: echo "Thingy<br>"; break;
//    }
//    echo "\n";
//}


//
//$b = "b";
////
//switch($b){
//    case "a":
//        echo "a";
//        break;
//    case "b":
//        echo "b";
//        break;
//    default:
//        echo "default";
//        break;
//}

//
//$i=0;
//
//switch($i)
//{
//    case 'TEST': print "Test";break;
//    case 0: print "0";break;
//}

$num='5';
//switch($num){
//    case '5.0aa' : echo '5.0!??'; break;
//    case '5' : echo '5.'; break;
//}

//switch('a'.$num.'.0'){
//    case 'a5' : echo '5.'; break;
//    case 'a5.0' : echo '5.0!??'; break;
//
//}


//switch(2) {
//    case 1:
//        echo "1";
//        break;
//    case 2:
//    default:
//        echo "2, default";
//        break;
//    case 3;
//        echo "3";
//        break;
//}

//switch(10) {
//    case 5: echo "Five\n"; break;
//    case 10: echo "Ten\n"; break;
//    case 6: echo "Six\n"; break;
//    case 10: echo "Tenaa\n"; break;
//}


//$string="second";
//switch ($string) {
//    case "first":
//    case "second":
//    case "third":
//        print "<H3>HELLO WORLD</H3><br>";
//        switch ($string) {
//            case "first":
//                print "es Firstn em";
//                break;
//            case "second":
//            case "third":
//                print "es errordn em";
//                break(2);
//            case 'asd':
//                echo 'ok';
//        }
//    default:
//        print "<H3>no match</H3>";
//}





//$bug = 0;
//switch ($bug !== 0 ? 'bar5' : $bug) {
//    case 'bar':
//        echo 'bar';
//        break;
//
//    case 'bar5':
//        echo 'bar2';
//        break;
//
//    default:
//        echo 'Ashxatel e defaulty';
//        break;
//}
//



//$a = "second";
//switch (false){
//    case ($a=="first"): print "first<br>"; break;
//    case ($a=="second"): print "second<br>"; break;
//}

//
//$x = 10;
//$y = 1;
//
//switch ($x) {
//    case ((($y * 4) && (9 * 3))? $x : false):
//        echo "Member";
//        break;
//    default:
//        echo "Not a member";
//}







// $x=1;
// $y=5;
// $z=$x<=>$y;
//
// switch ($z) {
// 	case 1:
// 		echo "max is x=$x and min is y=$y";
// 		break;
// 	case -1:
// 		echo "max is y=$y and min is x=$x";
// 		break;
//
// 	default:
// 		echo "x=y";
// 		break;
// }




?>