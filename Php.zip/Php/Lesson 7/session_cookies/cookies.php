<?php
// Inch e cookie-n?
//Cookies - local compi mej browserum tvyalner@ pahpanelu mexanizm e, veradardzox userneri hamar (nranc chanachelu kam hetevelu hamar)
//max 4000 simvol

//$name = "my_cookie";
//$value = 99;
//$expire = time() + (60*60*24*7*3); //time()--nerka pahn e, 60-ropeyum vayrkyanneri qanak, 60-jamum ropeneri qanak, 24-mek orum jameri qanak, 7-mek shabatum oreri qanak, 3-talis enq 3 shabat pahi cookie-n
////////
//setcookie($name, $value, $expire);

//var_dump($_COOKIE);
//echo $_COOKIE['my_cookie'];
// Removing cookie
//unset($_COOKIE['my_cookie']);
//var_dump($_COOKIE);
//CHISHT SA E

//setcookie('asdas');
//setcookie('my_cookie', null, time()-3600);
//
//var_dump($_COOKIE);


// print_r($_COOKIE);
// if(isset($_COOKIE['my_cookie'])){
// 	$test = $_COOKIE['my_cookie'];
// }else{
// 	$test = "";
// }
//nuynn e
//$test = isset($_COOKIE['my_cookie']) ? $_COOKIE['my_cookie'] : "";
////
//echo $test;



?>