<?php
// Sessian file e, vor pahpanvum e web serverum
// session-um karox enq pahpanel aveli shat info, qan cookie-nerum
// browser@ pakelis cookie-n jnjvum e, isk session-@ voch

//session_start();

//var_dump($_SESSION);
// Set session variables
// $_SESSION["favcolor"] = "green";
// $_SESSION["favanimal"] = "cat";
// echo "Session variables are set.";

//$_SESSION["name"] = "Hayk";
//$name = $_SESSION["name"];
//echo $name;
//
//print_r($_SESSION);

// to change a session variable, just overwrite it 
// $_SESSION["favcolor"] = "yellow";
// print_r($_SESSION);


// remove all session variables
// session_unset();
//print_r($_SESSION);
// echo $_SESSION['name'];
//print_r($_SESSION);
//
//// destroy the session
// print_r($_SESSION);




?>