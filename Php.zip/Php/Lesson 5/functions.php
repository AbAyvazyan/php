<?php


//function ok($a,$b){
//    echo $a + $b;
//}
//
//function br(){
//    echo '<br>';
//}
//
//ok(4,5);
//ok(7,9);

//function ok($a,$b){
//    return  $a + $b;
//}
//$a = ok(5,7);
//echo 'barev';
//echo $a;


//echo ok(4,10)/7;


// Declaration of function in PHP --- using the word "function"

//function sayHello($a,$b=5,$c=4){
//	echo $a.":".$b.":".$c; //
//}
//sayHello(10,7,5); //call the function

////Arguments
//function sayHello($name="bob") {
//    echo "Hello dear $name <br>";
//}
//sayHello();
//sayHello("John");
//sayHello("Bob");
//sayHello("Tom");
////more than one argument
//function sayHello($name, $surName) {
//    echo "Hello dear $name $surName <br>";
//}
//sayHello("Steve", "Jobs");
//sayHello("John", "Smith");
//sayHello("Bob", "Marley");
//sayHello("Tom", "Woo");
//
////Default Arguments
//function fontSize($size = 24) {
//    echo "The font size is : $size px <br>";
//    return $size;
//}
//$a = fontSize();
//var_dump($a);
//$a = 54;
//$a = fontSize();
//fontSize(); /// will use the default value (in this case 24)
//fontSize(64);
////
//
////Return
//function calculate($x, $y) {
//    $a = $x + $y;
//   return   $a;
//}
//////$a = calculate(5,6);
//////echo $a;
////echo "2 + 3 = " . calculate(2, 3) . "<br>";
////echo "4 + 5 = " . calculate(4, 5);
//
//echo calculate(2,3)+10;
//echo calculate(2,3)+7;

//

//function search($arr,$num){
//    echo (array_search($num,$arr)!==false)? array_search($num,$arr): 'Nope';
//}
//
//search([1,2,3,4,5,6],4);

?>