<?php
// SCOPE
//$var = 15;  /* global scope */
//function myFunction($var){
//	echo $var;
//}
//myFunction($var);// vochinch chi tpi, qani vor $var functioni NERSUM haytararac chi,


////------------------------------------------------------------------//
//$var1 = 10;
//$var2 = 15;
////echo '<pre>';
////print_r($GLOBALS);
//////////
//function Sum()
//{
//
//     global $var1, $var2;
////     $var1 = $GLOBALS['var1'];
////     $var2 = $GLOBALS['var2'];
//
////echo $var1,$var2;
//////
////    $sumOfVariables = $var1 + $var2;
////
////
////    /*
////     verevi erku toxeri poxaren karox enq
////    *  ogtagorcel $GLOBAL anunov array,
////    *  ev functioni mej el chgrenq global $var1 ev $var2, nuyn ardyunqn e linelu
////    *  $GLOBALS['sumOfVariables'] = $GLOBALS['var1'] + $GLOBALS['var2'];
////    */
//    $GLOBALS['sumOfVariables'] =$var1 + $var2;
//    $GLOBALS['a']=5;
////    echo $sumOfVariables;
//
//}
//Sum();
////
//echo $sumOfVariables;
//echo $a;
//$a = 7;
//echo "<pre>";
//print_r($GLOBALS);
//echo "</pre>";
//////-------------------------$GLOBALS----------------------------//
////// $GLOBALS - associative array  // superglobal e, kariq chka naxoroq grel "global" bare
// $GLOBALS['variable_name'=>'variable_value',...];


?>