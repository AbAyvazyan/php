<?php
$arr = range(1,100);
$prime = [];
$notPrime = [];
foreach($arr as $item){
    if($item==1){
        $notPrime[]=$item;
    }else{
        $bool = false;
        for($i=2;$i<=sqrt($item);$i++){
            if($item%$i==0){
                $notPrime[]=$item;
                $bool=true;
                break;
            }
        }
        if(!$bool){
            $prime[]=$item;
        }
    }
   
}
echo '<pre>';
print_r($prime);
print_r($notPrime);
?>