$arr = range(1,9);
foreach ($arr as $key => $value) {
	echo str_repeat($value,$value).'<br>;
}