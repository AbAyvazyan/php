<?php

// $arr = [1,2,3,4,5];

// echo array_sum($arr)/count($arr);

////-------------------------------------------2--------------------------------------------------

// 1
// 22
// 333
// 4444
// 55555
// 666666
// 7777777

// $num = 1; 
// function numpat($n) { 
    
    
    
//     for ($i = 0; $i < $n; $i++) 
//     { 
//         echo $GLOBALS["num"]."&nbsp";
//  echo "<br>";
        

//         if ($i<$GLOBALS["num"]) {
//             echo $GLOBALS["num"]."&nbsp";

//         }
        
//         $GLOBALS["num"]++;
            
        
//     } 
    
// } 
   
//     numpat(9); 



?>