<?php
include("connection.php");

$sql = "SELECT * FROM users ";
$result = mysqli_query($conn, $sql);
//var_dump($result);die;

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)){
//        echo '<pre>';
//        print_r($row);
//        die();
//        echo "<br>";

        echo "<div><h2>".$row['firstname']."</h2><p>".$row['lastname']."</p><span>".$row['age']."</span></div>";
//        echo "id: " . $row["id"]. " - Name: " . $row["name"]. " " . $row["brand"].'---' . $row["price"] . "<br>";
    }
} else {
    echo "0 results";
}
?>