<?php
/*
 * Вы можете определить константу с помощью функции define()
 * или с помощью ключевого слова const вне объявления класса с PHP 5.3.0.
 * Константы доступны из любой области видимости.
 *
 * Если использована конструкция const, константы могут содержать только
 * скалярные данные (типы boolean, integer, float и string).
 *
 *  С PHP 5.6 возможно определить константу как скалярное выражение,
 *  а также определить константу с типом array.
 */



//define('ANUN',[1,2]);
//print_r(ANUN);
//echo ANUN[0];
//const AZGANUN = "dsfsdf";

// chisht grelacev
//define('DB_HOST', 'localhost');
//define('DB_USER', 'root');
//define('DB_PASS', '');
//define('DB_NAME', 'php_courses');
//echo DB_HOST . '<br>';
//echo DB_USER . '<br>';
//echo DB_PASS . '<br>';
//echo DB_NAME . '<br>';

// sxal grelacev
//define("2HOST_NAME",   "localhost");

// Constanti haytararum@ const bari mijocov
//const DB_NAME = "MySQL";
//echo DB_NAME;

//  PHP 7
//define('ANIMALS', ['dog','cat','bird']);
//echo ANIMALS[1];


//$a = 'hello';
//
//$hello = 'world';
//
//$world = 'cat';
//
//echo  $$$a;

//
//echo "<h3>Postdecrement</h3>";
//$a = 5;
//echo  $a++ . "<br>";
//echo  $a . "<br>";
//
//echo "<h3>Preincrement</h3>";
//$a = 5;
//echo  ++$a . "<br>";
//echo  $a . "<br>";
//
//echo "<h3>Postdecrement</h3>";
//$a = 5;
//echo  $a-- . "<br>";
//echo  $a . "<br>";
////
//echo "<h3>Predecrement</h3>";
//$a = 5;
//echo  --$a . "<br>";
//echo  $a . "<br>";

//for($i=0;$i<10;$i++){
//    echo --$i;
//}

?>



