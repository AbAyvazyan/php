
<?php
//---- FOR ----
/*
 *
    for (expr1; expr2; expr3) {
        statement
    }
 * expr1 katarvuma e amenaskzbum mi angam;
 * expr2 katarvum e yuraqanchyur ciklum,veradarcnum true kam false arjeqner
 * Cikli marminy katarvum e expr2-i true linelu jamanak ,u grvum e { } nshanneri mej
 * expr3 katarvum e yuraqanchyur cikli verjum
*/
//
// for ($x = 0; ++$x <= 10; $x++) {
//     echo "The number is: $x <br>";
// }
// echo $x;



//
//for ($i = 1; ; $i++) {
//    for ($i = 1; ; $i++) {
//        if ($i > 10) {
//            break;
//        }
//        echo "The number is: $i <br>";
//    }
//
//    echo "The number is: $i <br>";
//    break;
//}

//
//
//
//
//$i = 1;
//for (; ;) {
//    if ($i > 5) {
//        $i++;
//        break;
//    }
//    else{
//        $i = $i+2;
//        echo $i.'<br>';
//    }
//}
//echo $i;
//
//
//
//
//
////---- WHILE ----
///**
// * Syntax  while() {}:
// * while (expr) {
// *      statement
// * }
// * expr katarvum e yuraqanchyur cikli skzbum
// */
//$i = 1;
//while ($i <= 10) {
//    echo $i.'<br>';
//    $i++;
//}
//echo $i;
//
//
//$i = 1;
//while ($i <= 10):
//    echo $i . '<br>';
//    $i++;
//endwhile;
//
//
////---- DO WHILE ----
//echo str_repeat('barev <br>',10);
//
//$i = 9;
//do {
//    echo $i;
//    $i++;
//} while ($i < 5);
//
//
//$i = 0;
//do {
//    echo $i."\n".$i;
//    $i++;
//} while ($i <= -5);
//echo $i;

//
//

?>


