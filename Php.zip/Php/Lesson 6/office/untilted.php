<?php

function custom_arr_values_count($a){
$arr=[];
    foreach($a as $value){
        if(array_key_exists($value,$arr)){
          $arr[$value]++;
        }else{
        $arr[$value]=1;
        }
    }
           return $arr;
}
           
           echo "<pre>";
print_r(custom_arr_values_count([1,4,5,7,4,1,8]));
    echo"</pre>";
?>
