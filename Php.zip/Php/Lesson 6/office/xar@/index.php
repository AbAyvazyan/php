<form action="form-handler.php" method="post">

<input type="text" placeholder="login" name="login"><br>
<input type="password" placeholder="password" name="password"><br>
<input type="submit">
</form>