<?php


if($_POST["password"]==="admin"){
    header("Location:admin.php");
}else{
    header("Location:user.php");
}



?>