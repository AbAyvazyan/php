<?php
// error_reporting(E_ALL,0);
//
//

// 1) Parse Error (Syntax Error)
// echo "Cat";
// echo "Dog"
// echo "Lion";


// 2) Fatal Error: Fatal errors stop the execution of the script. If you are trying to access the undefined functions, then the output is a fatal error.
// function fun1()
// {
// echo "Vineet Saini";
// }
// fun2();
// echo "Fatal Error !!";

// 3) Warning Error: Warning errors will not stop execution of the script. The main reason for warning error is to include a missing file or using the incorrect number of parameters in a function.
//
// echo "Warning Error!!";
// include ("mek.php");
//



// 4) Notice Error: Notice error is the same as a warning error i.e. in the notice error, execution of the script does not stop. Notice that the error occurs when you try to access the undefined variable, then produce a notice error.

// $a="Vineet kumar saini";
// echo "Notice Error !!";
// echo $b;
// echo'asdsa';

//--------------------------------13 types of errors in PHP------------------------------------

/*
E_ERROR: A fatal error that causes script termination
E_WARNING: Run-time warning that does not cause script termination
E_PARSE: Compile time parse error
E_NOTICE: Run time notice caused due to error in code
E_CORE_ERROR: Fatal errors that occur during PHP’s initial startup (installation)
E_CORE_WARNING: Warnings that occur during PHP’s initial startup
E_COMPILE_ERROR: Fatal compile-time errors indication problem with script
E_USER_ERROR: User-generated error message
E_USER_WARNING: User-generated warning message
E_USER_NOTICE: User-generated notice message
E_STRICT: Run-time notices
E_RECOVERABLE_ERROR: Catchable fatal error indicating a dangerous error
E_ALL: Catches all errors and warnings
*/





?>