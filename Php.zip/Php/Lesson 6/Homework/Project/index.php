<?php

echo "<br>This is index file!!<br>";

include ("app/upload.php");

include ("app/save.php");


?>