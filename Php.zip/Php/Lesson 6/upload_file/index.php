<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>File upload</title>
    <style>
        body {
            font-family: sans-serif;
        }
        #wrap{
            width: 500px;
            margin: 0 auto;
            text-align: center;
            background: #789;
            color: #fff;
            padding: 50px 0;
        }
        h3 {
            text-align: center;
        }
        .img-block {
            width: 500px;
            margin: 100px auto;
            overflow: hidden;
        }
        .img-block > img {
            width: 100%;
        }
    </style>
</head>
<body>
<!-- Тип кодирования данных, enctype, ДОЛЖЕН БЫТЬ указан ИМЕННО так -->
<!--Entype определяет вид кодировки, которую браузер применяет к параметрам формы.-->
<div id="wrap">
    <h2>Загрузка файлов на сервер</h2>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <p>
            <input type="file" name="files">
            <input type="submit" value="Отправить" name="upload">
        </p>
    </form>
</div>



<?php  if (isset($_GET['name'])): ?>
    <h3>Файл <b style="color: red;">
            <?= htmlentities($_GET['name']) ?></b> успешно загружен!
    </h3>
    <div class="img-block">
        <img src="img/<?= htmlentities($_GET['name']) ?>" alt="">
    </div>

<?php endif; ?>

</body>
</html>