<?php
/*
 * Глобальный массив $_FILES содержит всю информацию о загруженных файлах.
 *
 *
 * Оригинальное имя файла на компьютере клиента.
 * $_FILES['userfile']['name']
 *
 * Mime-тип файла, в случае, если браузер предоставил такую информацию.
 *  В качестве примера можно привести "img/gif". Этот mime-тип не
 * проверяется на стороне PHP, так что не полагайтесь на его значение
 * без проверки.
 * $_FILES['userfile']['type']
 *
 * Размер в байтах принятого файла.
 * $_FILES['userfile']['size']
 *
 * Временное имя, с которым принятый файл был сохранен на сервере.
 * $_FILES['userfile']['tmp_name']
 *
 * Код ошибки, которая может возникнуть при загрузке файла.
 * $_FILES['userfile']['error']
 *
 * По умолчанию принятые файлы сохраняются на сервере в стандартной
 * временной папке до тех пор, пока не будет задана другая директория при
 * помощи директивы upload_tmp_dir конфигурационного файла php.ini.
 *
 *
 * PHP.ini
 * Максимальное время выполнения каждого скрипта в секундах
 * max_execution_time = 3000
 *
 * Максимальная количество времени каждый сценарий может
 * потратить разбора запроса данных
 * max_input_time = 400
 *
 * Максимальный объем памяти, скрипт может потреблять (8 МБ)
 * memory_limit = 500M
 *
 * Максимальный размер данных POST, что PHP будет принимать.
 * post_max_size = 500M
 *
 * Максимально допустимый размер для загружаемых файлов.
 * upload_max_filesize = 200M
 *
 */

//function my_print(array $any_arr)
//{
//    echo '<pre>';
//    print_r($any_arr);
//    echo '</pre>';
//}

//my_print($_POST);die;
//my_print($_FILES);die;
//echo '<pre>';
//print_r($_FILES);die;


// Каталог загрузки картинок
$upload_dir = __DIR__ . '/img';




// Вывод ошибок
$err = [];

// Коды ошибок загрузки файла
$errUpload = [
    0 => 'Ошибок не возникло, файл был успешно загружен на сервер. ',
    1 => 'Размер принятого файла превысил максимально допустимый размер, который задан директивой upload_max_filesize конфигурационного файла php.ini.',
    2 => 'Размер загружаемого файла превысил значение MAX_FILE_SIZE, указанное в HTML-форме.',
    3 => 'Загружаемый файл был получен только частично.',
    4 => 'Файл не был загружен.',
    6 => 'Отсутствует временная папка. Добавлено в PHP 4.3.10 и PHP 5.0.3.'
];

// Определяем типы файлов для загрузки
$fileTypes = [
    'jpg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif'
];

// Если нажата кнопка загрузить
if (isset($_POST['upload'])) {

    // Проверяем пустые данные или нет
    if (!empty($_FILES)) {
//        echo '<pre>';
//        print_r($_FILES);die;

        // Проверяем на ошибки
        if ($_FILES['files']['error'] > 0) {
            $err[] = $errUpload[$_FILES['files']['error']];
        }
//        var_dump($_FILES['files']['type']);die;
//       echo $_FILES['files']['size'];exit;
        // Проверям тип файла для загрузки
        if (!(in_array($_FILES['files']['type'], $fileTypes))) {
            $err[] = 'Тип файла <b>' . $_FILES['files']['type'] . '</b> не подходит для загрузки!';
        }


        // Если нет ошибок то грузим файл
        if (empty($err)) {

            // pathinfo — Возвращает информацию о пути к файлу
            $type = pathinfo($_FILES['files']['name']);
//            print_r($type); die;

            // uniqid — Сгенерировать уникальный ID
            $name = $upload_dir . '/' . uniqid('files_') . '.' . $type['extension'];
            $file_name = pathinfo($name);
//            print_r($file_name);die;

            // move_uploaded_file — Перемещает загруженный файл в новое место
            move_uploaded_file($_FILES['files']['tmp_name'], $name);


            // Сбрасываем POST параметры
            header('Location: http://' . $_SERVER['HTTP_HOST'] . '/lesson 7/upload_file/index.php?name=' . $file_name['basename']);
            exit;
        } else
            echo implode('<br>', $err);

    }
}

