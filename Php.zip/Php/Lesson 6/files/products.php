<?php

$a = "hello";
$b = ' World';
return  [
    "botas1" => "nike",
    "botas2" => "adidas",
    "botas3" => "puma"
];

