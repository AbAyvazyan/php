<?php



include "products.php";


echo '<pre>';
//print_r($array);
echo $a;